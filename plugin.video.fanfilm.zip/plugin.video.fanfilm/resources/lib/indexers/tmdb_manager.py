import sys
import re
import requests  # chyba już niepotrzebne
from ptw.libraries import control
from ptw.libraries.log_utils import log, fflog, _is_debugging
from ptw.debug import log_exception, fflog_exc
from ptw.libraries import cache
import json


def tmdbManager(self, content, tmdb, season=None, episode=None, overlay="", progress=0, WatchedEpisodes=0):
    fflog(f'START \n{content=}  {tmdb=}  {season=}  {episode=}  {overlay=}  {progress=}  {WatchedEpisodes=}',1,1)

    season = "" if season is None else season
    episode = "" if episode is None else episode

    sysaddon = sys.argv[0]

    control.busy()
    control.sleep(200)

    # sprawdzenie, czy film lub serial jest na liście ulubionych lub obserwowanych i czy jest wystawiona ocena
    fflog('sprawdzenie występowania tytułu na ulubionych i obserwowanych oraz wystawionej oceny',1,1)
    url = f"https://api.themoviedb.org/3/{content}/{tmdb}/account_states?api_key=%s&session_id=%s" % (self.tm_user, self.tmdb_sessionid)
    fflog(f'{url=}',1,1)
    # import requests
    # result = requests.get(url)
    result = self.doRequest(url, repeat=0)
    if result:
        result = result.json()
        # fflog(f'{result=}',1,1)
        favorite  = result.get("favorite")
        watchlist = result.get("watchlist")
        rated = result.get("rated")
        rated = rated.get("value") if isinstance(rated, dict) else rated
        fflog(f'{favorite=}  {watchlist=}  {rated=}',1,1)
    else:
        favorite = watchlist = rated = None
        pass

    # sprawdzenie na jakich listach jest film lub serial.
    lists0 = None
    if 0:  # 0 to wyłączenie, bo ta metoda nie chce mi dobrze działać. Wyłapuje tylko na jakiejś dawno założonej liście. Na nowych nie widzi wcale.
        fflog('sprawdzenie występowanie tytułu na wszystkich listach',1,1)
        self.list = []  # na wszelki wypadek (choć to pierwszy request będzie, więc raczej nie trzeba
        url = f"https://api.themoviedb.org/3/{content}/{tmdb}/lists?api_key=%s&language=%s&page=1" % (self.tm_user, self.lang)
        # url = f"https://api.themoviedb.org/3/{content}/{tmdb}/lists?api_key=%s&page=1" % (self.tm_user)
        fflog(f'{url=}',1,1)
        result = self.tmdblist(url)
        lists0 = [(i["name"], i["id"]) for i in result]
        fflog(f'{lists0=}',1,1)
        self.list = []  # warto to wyczyścić

    items = []

    if not favorite:
        items += [( "[B]Dodaj[/B] [LIGHT]do[/LIGHT] Ulubionych",    self.tmdb_add_to_favourite_link, {"media_type": content, "media_id": int(tmdb), "favorite": True }, "", "(self.tmdb_list, self.tmdbuserfavourite_link)", "delcache" )]
        # control.log(f'1 {items=}',1)
    if favorite or favorite is None:
        items += [( "[I]Usuń[/I]  [LIGHT]z[/LIGHT]  Ulubionych",    self.tmdb_add_to_favourite_link, {"media_type": content, "media_id": int(tmdb), "favorite": False}, "", "(self.tmdb_list, self.tmdbuserfavourite_link)", "refresh" )]
        # control.log(f'2 {items=}',1)
    if not watchlist:
        items += [( "[B]Dodaj[/B] [LIGHT]do[/LIGHT] Obserwowanych", self.tmdb_add_to_watchlist_link, {"media_type": content, "media_id": int(tmdb), "watchlist": True }, "", "(self.tmdb_list, self.tmdbuserwatchlist_link)", "delcache" )]
        # control.log(f'3 {items=}',1)
    if watchlist or watchlist is None:
        items += [( "[I]Usuń[/I]  [LIGHT]z[/LIGHT]  Obserwowanych", self.tmdb_add_to_watchlist_link, {"media_type": content, "media_id": int(tmdb), "watchlist": False}, "", "(self.tmdb_list, self.tmdbuserwatchlist_link)", "refresh" )]
        # control.log(f'4 {items=}',1)

    # "Dodaj do nowej Listy" (zmieniam tuple na list, bo chcę potem zmodyfikować jeden z elementów)
    items += [[ control.lang(32520),  self.tmdbuserAddItems_link, {"items": [{"media_type": content, "media_id": int(tmdb)}]}, "", ("%.tmdblist", self.tmdb_user_lists), "delcache"]]
    # można by dodać jeszcze komendę na odświeżenia spisu list (chyba taki jak przy kasowaniu list będzie)
    # control.log(f'5 {items=}',1)

    self.list = []  # warto to wyczyścić (szczególnie, jeśli był poprzednio request w ramach tego samego wywołania akcji)
    result = self.tmdblist(self.tmdb_user_lists)  # pobranie list użytkownika
    self.list = []  # opcjpnalnie
    lists = [(i["name"], i["id"]) for i in result]
    # control.log(f'users {lists=}',1)

    if lists0 is None:  # jeśli poprzednia metoda sprawdzanie na jakich listach jest film
        if 1:  # sprawdzenie na jakich listach jest film lub serial.
            fflog('sprawdzenie występowanie tytułu na listach użytkownika',1,1)
            lists0 = []
            # można popytać o https://developer.themoviedb.org/reference/list-check-item-status
            # item_status_url = f"https://api.themoviedb.org/3/list/%s/item_status?language=pl-PL&movie_id={tmdb}&api_key={self.tm_user}&session_id={self.tmdb_sessionid}"  # tylko dla filmów to działa
            item_status_url = f"https://api.themoviedb.org/4/list/%s/item_status?&media_type={content}&media_id={tmdb}&api_key={self.tm_user}&session_id={self.tmdb_sessionid}"
            # control.log(f'{item_status_url=}',1)
            returns = []
            threads = None
            if len(lists) > 3:
                fflog('będą wątki',1,1)
                from threading import Thread
                threads = []
            for l in lists:
                fflog(f'{l=}',1,1)
                url = item_status_url % l[1]
                # control.log(f'{url=}',1)
                if threads is not None:
                    thread = Thread(target=self.doRequest, args=(url,), kwargs={"ret": returns, "key": l, "repeat": 0})
                    threads.append(thread)  # potrzebne do join
                    thread.start()
                else:
                    result = self.doRequest(url, repeat=0)  # requesty do serwera
                    # result = requests.get(url)  # będzie "troszkę" szybciej (alę tracę możliwość przejścia na v4)
                    returns.append(result)
            l = None
            if threads:
                # [i.start() for i in threads]
                fflog('czekam na skończenie wątków',1,1)
                [ i.join()  for i in threads ]
                fflog('koniec wątków',1,1)
                # fflog(f'wątki {returns=}',1,1)
            # fflog(f'{returns=}',1,1)
            for i, result in enumerate(returns):  # przy wątkach wyniki nie muszą być w kolejności wywołania
                fflog(f'{i=}  {result=}',1,1)
                if isinstance(result, dict):
                    l, result = next(iter(result.items()), (None, None))
                    # fflog(f'{l=}  {result=}',1,1)
                else:
                    l = lists[i]
                if result:
                    result = result.json()
                    fflog(f'{result=}',1,1)
                    item_present  = result.get("item_present") or result.get("success")
                    fflog(f'{item_present=}',1,1)
                    if item_present:
                        fflog(f'dodaje {l=}',1,1)
                        lists0.append(l)
                else:
                    fflog(f'{result=}',1,1)
                    if result is not None:
                        fflog(f'{result.text=}',1,1)
                    
            fflog(f'{lists0=}',1,1)

    lists = [lists[i // 2] for i in range(len(lists) * 2)]  # powielenie
  
  # na dodawanie do listy
    for i in range(0, len(lists), 2):
        # fflog(f'{lists[i]=}',1,1)
        if lists0 is not None:
            if lists[i] in lists0:
                lists[i] = None
                continue
        lists[i] = (
            (control.lang(32521) % lists[i][0]),
            # self.tmdbuserAddItem_link % lists[i][1],  # v3
            self.tmdbuserAddItems_link % lists[i][1],  # v4
            { "items": [  #v4
                {"media_id": int(tmdb),
                 "media_type": content,  # to dopiero od v4
                },
            ] },  #v4
            "",  # method (GET, POST, DELETE)
            ("self.tmdb_list", self.tmdb_lists_link % lists[i][1]), "delcache",
        )
    # na usuwanie z listy
    for i in range(1, len(lists), 2):
        # fflog(f'{lists[i]=}',1,1)
        if lists0 is not None:
            if lists[i] not in lists0:
                lists[i] = None
                continue
        lists[i] = (
            (control.lang(32522) % lists[i][0]),
            # self.tmdbuserRemoveItem_link % lists[i][1],  # v3
            self.tmdbuserRemoveItems_link % lists[i][1],  # v4
            { "items": [  #v4
                {"media_id": int(tmdb),
                 "media_type": content,  # to dopiero od v4
                },
            ] },  #v4
            "DELETE",  # method (GET, POST, DELETE)  # DELETE przy v4 bo dla v3 jest POST
            ("self.tmdb_list", self.tmdb_lists_link % lists[i][1]), "refresh",
        )
    # control.log(f'{lists=}',1)
    lists = list(filter(None, lists))  # usunięcie pustych
    # control.log(f'{lists=}',1)
    items += lists  # dodanie do listy managera

    if overlay == "7" or progress and progress > 40 or WatchedEpisodes and WatchedEpisodes > 1:
        items += [( "Oceń"+(" [LIGHT]ponownie[/LIGHT]"+f" (obecnie {rated})" if rated else ""),   "RunPlugin(%s?action=add_rating&content=%s&tmdb=%s&season=%s&episode=%s)" % (sysaddon, content, tmdb, season, episode), )]  # RunPlugin wykonuje się asynchronicznie

    # items += [( "Odśwież katalog", "test", "(self.tmdb_list, self.tmdbuserfavourite_link)", "refresh" )]  # na test tylko

    # control.log(f'{type(items)=}  {items=}',1)
    # control.log(f'items={json.dumps(items, indent=2)}',1)

    control.idle(2)
    control.sleep(200)

    select = control.selectDialog( [i[0] for i in items], "Menadżer TMDB" )  # wyświetlenie okienka wyboru


    if select == -1:
        return
    elif items[select][1].startswith("Run"):
        control.execute(items[select][1])
        return
    elif items[select][1].startswith("test"):  # to testów tylko
        pass
        fflog(f'do testów tylko',1,1)
        """
        # url2  = control.infoLabel('Container.FolderPath')
        # fflog(f'{url2=}',1,1)
        # url2 += "&refresh=1" if not "refresh=1" in url2 else ""
        # fflog(f'{url2=}',1,1)
        # control.update(url2, replace=1)  # 1 lub 0 (1 nie zastępuje obecnej strony (dodaje do historii kolejną), a 0 niszczy całą historię)
        control.refresh()  # to jest neutralne, tylko, że nie mogę dodać parametru
        """
        return
    else:

        def handlingRequest(url=None, post=None, method=None, repeat=0):  # definiuje jako funkcję, bo potrzebuję użyć 2 razy
            """ funkcja pomocnicza """

            control.busy()
            control.sleep(200)

            if post is None:
                post = post if isinstance(post := items[select][2], dict) else ""
            if url is None:
                url = items[select][1]
            if method is None:
                method = items[select][3]
                pass

            result = self.doRequest(url, post, method, repeat)  # zapytanie do serwera

            try:
                msg = result.json()
                try:
                    msg = msg.get("status_message") or ""
                except:
                    pass
                msg = f'\n[LIGHT][I]{msg}[/I][/LIGHT]' if msg else ""
            except:
                msg = result.text
                pass

            icon = control.infoLabel("ListItem.Icon") if result else "ERROR"  # jak to działa z tym infoLabel("ListItem.Icon") ?
            control.infoDialog(
                ("NIE " if icon == "ERROR" else "") + "wykonano poprawnie" + msg,
                heading="Menadżer TMDB",
                sound=True,
                icon=icon,
            )

            control.idle(2)
            control.sleep(200)
            return result


        if items[select][0] == control.lang(32520):  # dodanie do NOWEJ listy
            t = control.lang(32520)
            k = control.keyboard("", t)  # pytanie o nazwę nowej listy
            k.doModal()
            new = k.getText() if k.isConfirmed() else None
            if new == None or new == "":
                return

            post = payload = {
                "name": new,
                "description": "",  # musi być taki rekord
                "language": "pl",
            }
            # result = self.doRequest(self.tmdbuserCreateList_link, post=post)
            result = handlingRequest(self.tmdbuserCreateList_link, payload)
            if result:
                # dobrze byłoby jeszcze sprawdzić status odpowiedzi od tmdb
                status_code = result.json().get("status_code")
                fflog(f'{result.text=}',1,1)
                list_id = result.json().get("list_id")
                items[select][1] = items[select][1] % list_id  # tylko modyfikacja parametru
            else:
                return


        handlingRequest()  # albo powyższe (do NOWEJ listy), albo coś z istniejącą listą do zrobienia


        if items[select][-1] in ["delcache", "refresh"]:
            fflog(f'usuwam z cache',1,1)  # 1 stronę
            key = items[select][-2]
            fflog(f'{key=}',1,1)
            if isinstance(key, str):  # bo powinna być krotka
                key = eval(key)
            fflog(f'{key=}',1,1)
            name, url = key
            if isinstance(name, str) and "%" not in name:  # bo powinna tu być funkcja
                name = eval(name)  # chodzi o prawidłowe określenie nazwy funkcji (np. movies.tmdb_list)
                fflog(f'{name=}',1,1)
                pass
            fflog(f'{name=}  {url=}',1,1)

            def cache_remove(name, url, key=None):
                key = (name, url) if not key else key
                if isinstance(name, str) and "%" in name:
                    status = cache.remove(*key, like=True)  # usunięcie z cache
                else:
                    status = cache.remove(*key)  # usunięcie z cache
                return status

            url = re.sub("((?<=[?/])|&)(page[=/])([^&])", r"\1\2{}", url).replace("?&", "?").rstrip("?&")
            if "{}" in url:
                for n in range(1,10):  # do ilu jechać ?
                    urlN = url.format(n)
                    key = (name, urlN)
                    # fflog(f'{key=}',1,1)
                    status = cache_remove(name, urlN)  # próba usunięcia z cache
                    if status is False:
                        if n == 1:
                            fflog('usuwam wartości kluczy z adresu',1,1)
                            url = re.sub("(?<=api_key=)[^&]*", "", url)
                            url = re.sub("(?<=session_id=)[^&]*", "", url)
                            fflog(f'{url=}',1,1)
                            urlN = url.format(n)
                            key = (name, urlN)
                            status = cache_remove(name, urlN)  # próba usunięcia z cache
                            if status is False:
                                fflog('usuwam zmienne kluczy z adresu (jeśli są)',1,1)
                                url = re.sub(r"[&]?\bapi_key=[^&]*", "", url)
                                url = re.sub(r"[&]?\bsession_id=[^&]*", "", url)
                                url = url.rstrip("?")
                                fflog(f'{url=}',1,1)
                                urlN = url.format(n)
                                key = (name, urlN)
                                status = cache_remove(name, urlN)  # próba usunięcia z cache
                                if status is False:
                                    fflog(f'{status=} co oznacza, że nie ma cache dla tej funkcji {key=}',1,1)
                                    break
                        else:
                            fflog(f'{status=} co oznacza, że nie ma więcej stron',1,1)
                            break  # nie ma sensu próbować kolejnych stron
            else:
                # key = (name, url)
                status = cache_remove(name, url)  # próba usunięcia z cache
                if status is False:
                    fflog('usuwam wartości kluczy z adresu',1,1)
                    url = re.sub("(?<=api_key=)[^&]*", "", url)
                    url = re.sub("(?<=session_id=)[^&]*", "", url)
                    fflog(f'{url=}',1,1)
                    status = cache_remove(name, url)  # próba usunięcia z cache
                    if status is False:
                        fflog('usuwam zmienne kluczy z adresu (jeśli są)',1,1)
                        url = re.sub(r"[&]?\bapi_key=[^&]*", "", url)
                        url = re.sub(r"[&]?\bsession_id=[^&]*", "", url)
                        url = url.rstrip("?")
                        fflog(f'{url=}',1,1)
                        status = cache_remove(name, url)  # próba usunięcia z cache
                        if status is False:
                            fflog(f'{status=} co oznacza, że nie ma cache dla tej funkcji {key=}',1,1)
                            pass


        if items[select][-1] == "refresh":
            fflog(f'odświeżam katalog',1,1)
            control.refresh()



def doRequest(self, url, post="", method="", repeat=0, headers=None, ret=None, key=None):  # repeat było 9
    """ wykonuje zapytania do serwera TMDB """
    import requests

    method = method if method else "get" if not post else "post"
    fflog(f'\n',1,1)
    fflog(f'{method=}',1,1)

    payload = post if isinstance(post, dict) else {}  # albo None

    if 1:
        # control.log(f'{self}',1)
        # control.log(f'{self.tmdb_access_token=}',1)
        # control.log(f'{self.tm_bearer=}',1)
        # bearer = self.tmdb_access_token or self.tm_bearer
        # control.log(f'{bearer=}',1)
        # return
        if (
            "/4/" in url
            # or self.tm_bearer
            # or self.tmdb_access_token  # ten ważniejszy (zastępuje nawet session_id)
           ):  # v4 API
            fflog(f'wersja v4 API',1,1) if "/4/" in url else ""
            if headers is None:
                bearer = self.tmdb_access_token or self.tm_bearer
                headers = {
                    "accept": "application/json",
                    "content-type": "application/json",  # czy to tylko przy post?
                    # "Authorization": f"Bearer {self.tm_bearer}"  # nie wiem, który powinien być
                    # "Authorization": f"Bearer {self.tmdb_access_token}"  # nie wiem, który powinien być
                    "Authorization": f"Bearer {bearer}"
                }
                if (method.lower() == "get"
                    # or (not post and not payload)
                    ):
                    headers.pop("content-type")  # bo niepotrzebne?
                    pass
            if 0 and bearer:
                control.log(f'[FanFilm]  [tmdb_manager.py]  [doRequest]  {url=}',1)
                fflog('usuwam zmienne kluczy z adresu',1,1)
                url = re.sub(r"[&]?\bapi_key=[^&]*", "", url)
                url = re.sub(r"[&]?\bsession_id=[^&]*", "", url)  # kurcze, tylko w niektórych endpointach wg dokumentacji to jest wymagane
                url = url.rstrip("?")
                fflog(f'{url=}',1,1)
        else:
            if headers is None:
                headers = {}
            # potrzebne, jak wykorzystuję tę metodę z innych metod
            # dodanie danych autoryzacyjnych (gdy potrzebne)
            url = re.sub("(?<=api_key=)[^&]*", self.tm_user, url)
            url = re.sub("(?<=session_id=)[^&]*", self.tmdb_sessionid, url)

    if headers is None:
        headers = {}  # bo nie wiem, czy None nie spowoduje jakiejś awarii przy requests
        pass

    monitor = control.monitor
    # counter = 10
    counter = repeat + 1

    while True:

        if method.lower() == "get":
            tmdb_results = requests.get(url, headers=headers)
        elif method.lower() == "post":
            if payload:
                tmdb_results = requests.post(url, json=payload, headers=headers)
            else:
                tmdb_results = requests.post(url, data=post, headers=headers)
        elif method.lower() == "delete":
            tmdb_results = requests.delete(url, json=payload, headers=headers)
        elif method.lower() == "put":
            tmdb_results = requests.put(url, json=payload, headers=headers)  # zrobić ewentualnie jak przy post - data lub json

        if not tmdb_results and tmdb_results is not None and tmdb_results.status_code == 404:
            # fflog(f'wystąpił jakiś problem  ',1,1)
            fflog(f'wystąpił jakiś problem  {tmdb_results=}  \n  {tmdb_results.text=}  \n  {post=}  \n  {method=}  \n  {url=}',1,1)
            try:
                status_code = tmdb_results.json().get("status_code")
                if status_code not in [34]:  # https://developer.themoviedb.org/docs/errors
                    break
            except:
                break
            counter -= 1
            if counter > 0:
                control.log(f'czekam przed ponowieniem żądania do serwera  {counter=}',1)
                control.sleep(5000)
                if monitor.abortRequested():
                    break
            else:
                break
        else:
            break

    if 0:  # wymyśleć może jakiś warunek
    # if _is_debugging:
        fflog(f'\n {tmdb_results=}  \n {tmdb_results.text=}  \n {post=}  \n {method=}  \n {url=}  \n {headers=}',1,1)
        pass

    fflog(f'\n',1,1)
    # if ret is not None:
    if isinstance(ret, list):
        if key:
            ret.append({key: tmdb_results})
        else:
            ret.append(tmdb_results)
    elif ret is True:
        if key:
            returns.append({key: tmdb_results})
        else:
            returns.append(tmdb_results)  # zakładam, że mam taką zmienną "returns" wcześniej zdefiniowaną
    return tmdb_results

