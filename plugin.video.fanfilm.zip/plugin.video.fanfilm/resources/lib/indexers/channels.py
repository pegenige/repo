"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
from ptw.debug import log_exception, fflog_exc, fflog

from urllib.parse import quote_plus

from threading import Thread, Lock
lock = Lock()

from concurrent.futures import ThreadPoolExecutor

import time

import requests

from resources.lib.indexers import navigator
addDirectoryItem = navigator.navigator().addDirectoryItem

from ptw.libraries import control
from ptw.libraries import cache

# from bs4 import BeautifulSoup

# filmweb_url = "http://www.filmweb.pl"
# result = requests.get("http://www.filmweb.pl/program-tv")

# soup = BeautifulSoup(result, "html.parser")
# fflog(f'{soup=}',1)

import sys
# sysaddon = "plugin://plugin.video.fanfilm/"
sysaddon = sys.argv[0]

def get():

    img_prefix = "https://fwcdn.pl/fpo"
    base = "http://www.filmweb.pl"
    api = "api/v1"

    url = f"{base}/{api}/channels"
    fflog(f'{url=}',0,1)
    # channels_list = requests.get(url, timeout=30).json()  # zrobić do cache na 24 albo i wiecej godz
    channels_list = cache.get(requests.get, 72, url, callback=".json()")
    # fflog(f'{channels_list=}',1,1)

    unwanted = [97,155,102,64,65,68,15,61,118,122,37,286,143,180,147,245,123,279,153,133,292,300,396,150,417,405,411,412,419,430,426,427,428,433,355,353,236,381,347,177]
    unwanted += [363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379]  # regionalne


    monitor = control.monitor


    import datetime
    datetime = datetime.datetime.utcnow() - datetime.timedelta(hours=5)
    today_date = datetime.strftime("%Y-%m-%d")
    fflog(f'{today_date=}')

    url = f"{base}/{api}/channels/search?seanceType=TV_FILM&date={today_date}"
    # fflog(f'{url=}',1,1)
    # result = requests.get(url)  # do cache na 24 godz
    result = cache.get(requests.get, 12, url, callback=".json()")

    if not result:
        fflog(f'{result=}',1)
        pass
        
    if 0:
        # result = result.content
        # fflog(f'{result.text=}',1)
        # result = result.json()
        # fflog(f'{result=}',1)
        pass

    generate_short_path = control.setting("generate_short_path") == "true"

    counter = 0

    DirectoryItems = []

    def scrap_channel(ch, chn):
        try:
            # global counter
            nonlocal counter

            url = f"{base}/{api}/channels/{ch}/tv-guide?date={today_date}"
            # fflog(f'{url=}',1,1)
            # result2 = requests.get(url, timeout=10).json()  # tez dać do cache
            result2 = cache.get(requests.get, 12, url, callback=".json()")

            if not result2:
                fflog(f'{result2=}',1)
                pass

            # fflog(f'{len(result2)=}  ({ch=})',1)
            for p in result2:

                if monitor.abortRequested():
                    fflog('sygnal zamknięcia Kodi',1,1)
                    sys.exit()

                duration = p.get("duration")
                rate = p.get("rate")
                # entityName = p.get("entityName")  # "film" ale niektóre nie mają tego wcale - chyba, że to tylko dla jakiś mało znanych produkcji?
                description = p.get("description") or ""

                if (p.get("type") == 1
                    and duration > 69  # 49 spróbować
                    and "dokumentalny" not in description
                    and "film erotyczny" not in description
                    and rate is not None
                    ):

                    titlef = p.get("title")

                    yearf = img = titleo = plotoutline = director = ""
                    cast = []

                    if 1:
                        fid = p.get("film")
                        if fid:
                            url = f"{base}/{api}/title/{fid}/info"
                            url = f"{base}/{api}/film/{fid}/preview"
                            # fflog(f'{url=}',1,1)
                            result3 = {}
                            # result3 = requests.get(url, timeout=10).json()  # tez dać do cache
                            result3 = cache.get(requests.get, 72, url, callback=".json()")
                            
                            subType = result3.get("subType")
                            if subType == "film_tv":
                                continue
                                pass

                            # titlef = result3.get("title")

                            titleo = result3.get("originalTitle")
                            titleo = titleo["title"] if isinstance(titleo, dict) else titleo

                            yearf = result3.get("year") or ""

                            duration = result3.get("duration") if "duration" in result3 else duration

                            img = result3.get("poster", {}).get("path") or ""
                            img = (result3.get("posterPath") or "") if not img else img
                            img = img.replace("$", "3")  # ewentualnie 2
                            img = img_prefix + img if img else ""
                            # fflog(f'{img=}',1,1)

                            plotoutline = result3.get("plotOrDescriptionSynopsis") or ""

                            # cast = []
                            for person in result3.get("mainCast", {}):
                                cast.append({
                                    "name": person.get("name") or "",
                                })

                            director = result3.get("directors") or ""
                            if director:
                                director = director[0]["name"]

                    if not img:
                        img = "channels.png"  # zastępcza grafika

                    zonedStartTime = p.get("zonedStartTime")
                    startat = zonedStartTime.split("T")[1].rsplit(":",2)[0] if zonedStartTime else ""

                    tvh = f"{startat}, {chn}".strip(", ") if chn else ""

                    genre = p.get("description")

                    if description:
                        if description not in ["baśń filmowa", "czarna komedia", "komedia sensacyjna", "komedia obyczajowa", "komedia kryminalna"]:
                            description = description.split(" ")[-1].replace("czna", "czny", 1).replace("kostiumowa", "kostiumowy", 1)
                        # description = description.partition(" ")[-1]
                        description  = f'  |  [LIGHT]{description}[/LIGHT]'
                        description += f', [LIGHT]{duration} min.[/LIGHT]' if duration else ""
                        # description += f' [LIGHT][I]{round(rate,1)}[/I][/LIGHT] *' if rate else ""  # ocena
                        pass
                    # description = ""

                    plot = p.get("notes")
                    duration = p.get("duration")

                    meta = {"title": titlef,
                            "year": yearf,
                            "plot": plot,
                            "duration": duration*60,
                            "genre": genre,
                            "rating": rate, 
                            #"ChannelName": chn, "ChannelNumber": ch, "ChannelNumberLabel": ch,  # nie działa do sortowania
                            # "dateadded": zonedStartTime.split("+")[0].replace("T", " "),  # bez rezultatu dla sortowania
                            "datetime": zonedStartTime,
                            "originaltitle": titleo,
                            "plotoutline": plotoutline,
                            "cast": cast,
                            "director": director,
                            "mediatype": "movie",
                            "trailer": "%s?action=trailer&name=%s" % (sysaddon, quote_plus(f'{titlef} ({yearf})')),  # wyszukuje w YouTube
                            }

                    with lock:
                        counter += 1
                        # fflog(f'{counter=}',1,1)

                    if yearf:
                        # addDirectoryItem(
                        DirectoryItems.append({"zonedStartTime": zonedStartTime, "args": (
                            titlef + " [LIGHT][COLOR grey][I]("+str(yearf)+"r.)[/I][/COLOR][/LIGHT]  |  [B]"+tvh+"[/B]" + description,
                            "movieSearchEPG&item=%s"%counter if generate_short_path else "movieSearchEPG&name=%s&year=%s" % (quote_plus(titleo or titlef), str(yearf)),
                            img, img,
                            ("Wyszukuj z pominięciem roku", "movieSearchEPG&year=0&item=%s"%counter if generate_short_path else "movieSearchEPG&name=%s" % quote_plus(titleo or titlef) , "Container.Update" if generate_short_path else "ActivateWindow"),
                            ), "kwargs": {"meta": meta}}
                            # meta=meta,
                        )
                    else:
                        # addDirectoryItem(
                        DirectoryItems.append({"zonedStartTime": zonedStartTime, "args": (
                            titlef + "  |  [B]"+tvh+"[/B]" + description,
                            "movieSearchEPG&item=%s"%counter if generate_short_path else "movieSearchEPG&name=%s" % quote_plus(titleo or titlef),
                            # "movieSearchEPG&year=0&item=%s"%counter if generate_short_path else "movieSearchEPG&name=%s" % quote_plus(titleo or titlef),
                            img, img,
                            # meta=meta,
                            ), "kwargs": {"meta": meta}}
                        )

        except Exception:
            fflog_exc(1)
            pass



    start = time.time()


    with ThreadPoolExecutor(max_workers=10) as executor:

        fflog(f'{len(result)=} (kanałów do sprawdzenia)',1,1)
        for ch in result:

            if ch in unwanted:  # id kanałów, które pomijać
                continue
                pass

            chn = ""
            for c in channels_list:
                if c["id"] == ch:
                    chn = c["name"]
                    fflog(f'{chn=} ({ch})',0,1)
                    break

            if chn in []:  # wpisać nazwy kanałów, które pomijać
                continue
                pass

            # fflog(f'zaczynam scrapowanie kanałów',1,1)
            # scrap_channel(ch)
            executor.submit(scrap_channel, ch, chn)


    stop = time.time()

    fflog(f"Exec time: {stop - start} [s]",1,1)


    # fflog(f'{counter=}',1,1)

    fflog(f'{len(DirectoryItems)=}',1,1)
    # import json
    # fflog(f'DirectoryItems={json.dumps(DirectoryItems, indent=2)}',1,1)

    list_of_items = []

    if generate_short_path:
        import re
        sub_re = re.compile("(?<=item=)[^&]*")

    # próba eliminacji tych samych filmów
    if 1:
        DirectoryItems = [ item  for i,item in enumerate(DirectoryItems)
                            if not item["kwargs"]["meta"]["plot"]
                               or not any(item["kwargs"]["meta"]["plot"] == dI["kwargs"]["meta"]["plot"] for dI in DirectoryItems[:i])
                        ]
        fflog(f'{len(DirectoryItems)=}',1,1)

    if generate_short_path:
        DirectoryItems = sorted( DirectoryItems, key=lambda k: (k["zonedStartTime"], k["args"][0]) )

    for i, item in enumerate( DirectoryItems ):

        if generate_short_path:
            i += 1
            item["args"] = list(item["args"])
            item["args"][1] = sub_re.sub(str(i), item["args"][1])
            if len(item["args"]) > 4:
                item["args"][4] = list(item["args"][4])
                item["args"][4][1] = sub_re.sub(str(i), item["args"][4][1])
                item["args"][4] = tuple(item["args"][4])
            # item["args"] = tuple(item["args"])
            # fflog(f'{item["args"]=}',1,1)

        # addDirectoryItem(*item["args"], **item["kwargs"], counter=i)
        list_of_items.append( addDirectoryItem(*item["args"], **item["kwargs"], counter=i, ret=True) )
    if list_of_items:
        navigator.navigator().addDirectoryItems(list_of_items)  # dodanie zbiorcze

    list_of_items = DirectoryItems = None


    from xbmcplugin import addSortMethod, SORT_METHOD_UNSORTED, SORT_METHOD_PLAYLIST_ORDER, SORT_METHOD_LABEL, SORT_METHOD_TITLE, SORT_METHOD_VIDEO_YEAR, SORT_METHOD_DURATION, SORT_METHOD_VIDEO_RATING, SORT_METHOD_GENRE, SORT_METHOD_DATE, SORT_METHOD_CHANNEL
    # import sys
    syshandle = int(sys.argv[1])
    # https://romanvm.github.io/Kodistubs/_autosummary/xbmcplugin.html#xbmcplugin.addSortMethod
    # addSortMethod(syshandle, sortMethod=SORT_METHOD_UNSORTED, labelMask="%L")  # pokazuje napis "Domyślny", ale nie sortuje
    # addSortMethod(syshandle, sortMethod=SORT_METHOD_PLAYLIST_ORDER, labelMask="%L")  # wykorzystuje countera, napis "Lista odtwarzania"
    addSortMethod(syshandle, sortMethod=SORT_METHOD_DATE, labelMask="%L")
    addSortMethod(syshandle, sortMethod=SORT_METHOD_VIDEO_YEAR, labelMask="%L")
    addSortMethod(syshandle, sortMethod=SORT_METHOD_VIDEO_RATING, labelMask="%L")
    addSortMethod(syshandle, sortMethod=SORT_METHOD_GENRE, labelMask="%L")
    addSortMethod(syshandle, sortMethod=SORT_METHOD_DURATION, labelMask="%L")
    # addSortMethod(syshandle, sortMethod=SORT_METHOD_CHANNEL, labelMask="%L")  # kanał - nie wiem, jak ustawić dane do tego sortowania
    addSortMethod(syshandle, sortMethod=SORT_METHOD_TITLE, labelMask="%L")


    navigator.navigator().endDirectory(category="Dziś w TV")


    # control.content(syshandle, "movies")  # potestować ewentualnie dla różnych skórek
