# -*- coding: utf-8 -*-
"""
FanFilm • Źródło: film.telewizjada.cc
// bez filmów mpd oraz bez seriali
Copyright (C) 2025 :)

Dystrybuowane na licencji GPL-3.0.
"""
import json
import re
import urllib3
from html import unescape
from urllib.parse import quote_plus, urljoin, quote, urlencode

import requests
from ptw.libraries import source_utils, client, cleantitle
from ptw.debug import fflog_exc, fflog

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        self.domains = ["film.telewizjada.cc"]
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
            "DNT": "1",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
        }
        self.base_link = "https://film.telewizjada.cc"
        self.search_link = "/search?q=%s"

    def movie(self, imdb, title, localtitle, aliases, year):
        return self.do_search(title, localtitle, year, "movie", aliases)
    """
    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        return self.do_search(tvshowtitle, localtvshowtitle, year, "tvshow", aliases)

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        if not url:
            # fflog(f'{url=}',1,1)
            return None
        try:
            # fflog(f"Pobieranie odcinka: S{season}E{episode} dla {url}")
            page_content = requests.get(url, headers=self.headers, timeout=30).text
            season_content = ''
            season_blocks = re.split(r'(<div class="movie-heading.*?<span>Sezon \d+</span>.*?</div>)', page_content)
            if len(season_blocks) > 1:
                for i in range(1, len(season_blocks), 2):
                    header = season_blocks[i]
                    content = season_blocks[i+1]
                    s_match = re.search(r'Sezon (\d+)', header, re.I)
                    if not s_match: continue
                    s_num = int(s_match.group(1))
                    if s_num == int(season):
                        season_content = content
                        break
            else:
                if int(season) == 1:
                    season_content = page_content
            if not season_content:
                fflog(f"Nie znaleziono sezonu {season}")
                return None
            ep_items = client.parseDOM(season_content, 'div', attrs={'class': 'item'})
            for item in ep_items:
                ep_caption_tag = client.parseDOM(item, 'figcaption')
                if not ep_caption_tag: continue
                ep_caption = ep_caption_tag[0]
                ep_num_match = re.search(r'Odcinek (\d+)', ep_caption, re.I)
                if not ep_num_match: continue
                ep_num = int(ep_num_match.group(1))
                if ep_num == int(episode):
                    ep_url_tag = client.parseDOM(item, 'a', ret='href')
                    if not ep_url_tag: continue
                    ep_url = ep_url_tag[0]
                    if not ep_url.startswith("http"):
                        ep_url = urljoin(self.base_link, ep_url)
                    # fflog(f"Znaleziono link do strony odcinka: {ep_url}")
                    return ep_url
            fflog(f"Nie znaleziono odcinka {episode} w sezonie {season}")
            return None
        except Exception:
            fflog_exc(1)
            return None
    """

    def do_search(self, title, localtitle, year, content_type, aliases=None):
        try:
            # Priorytet: polskie tytuły jako główne, angielskie jako fallback
            titles_to_search = []

            # Dla polskiego tytułu spróbujmy różnych wariantów
            if localtitle and localtitle.strip():
                # Oryginalny polski tytuł
                titles_to_search.append(localtitle.strip())

                # Zamień kropkę na dwukropek (często różnica między bazami)
                with_colon = localtitle.replace('.', ':').strip()
                if with_colon != localtitle:
                    titles_to_search.append(with_colon)

                # Uproszczony (bez znaków specjalnych)
                simplified = localtitle.replace('.', '').replace(':', '').strip()
                if simplified not in [localtitle, with_colon]:
                    titles_to_search.append(simplified)

            if title and title.strip() and title != localtitle:
                titles_to_search.append(title.strip())
                # fflog(f"Dodano angielski tytuł: '{title}'")

            # Ograniczamy do maksymalnie 4 tytułów
            titles_to_search = titles_to_search[:4]

            # Przeszukaj każdy tytuł
            for idx, search_title in enumerate(titles_to_search):
                try:
                    # fflog(f"[{idx+1}/{len(titles_to_search)}] Szukam: '{search_title}'")

                    # Wykonaj wyszukiwanie
                    search_url = self.base_link + self.search_link % quote_plus(search_title)
                    # fflog(f"URL wyszukiwania: {search_url}")

                    result = requests.get(search_url, headers=self.headers, timeout=60)
                    if not result or result.status_code != 200:
                        # fflog(f"Błąd HTTP: {result.status_code if result else 'None'}")
                        continue

                    result = result.text

                    if not result:
                        # fflog(f"[{idx+1}/{len(titles_to_search)}] Nie udało się pobrać wyników")
                        continue

                    # ====== PARSOWANIE - szukanie bezpośrednio linków /watch/ ======
                    search_results = []

                    # Szukaj wszystkich linków do /watch/*.html (zarówno względnych jak i pełnych)
                    watch_links = re.findall(r'href="([^"]*\/watch\/[^"]*\.html)"', result)
                    # fflog(f"Znaleziono {len(watch_links)} linków /watch/")

                    for link in watch_links:
                        # Kompletuj URL
                        if not link.startswith("http"):
                            full_url = urljoin(self.base_link, link)
                        else:
                            full_url = link

                        # Szukaj tytułu dla tego linku - może być w <a> lub w <h3><a>
                        title_patterns = [
                            rf'<a[^>]*href="{re.escape(link)}"[^>]*>([^<]+)</a>',
                            rf'href="{re.escape(link)}"[^>]*>([^<]+)</a>',
                        ]

                        found_title = ""
                        for pattern in title_patterns:
                            title_match = re.search(pattern, result)
                            if title_match:
                                found_title = unescape(title_match.group(1).strip())
                                break

                        if not found_title:
                            # Fallback - wyciągnij z URL
                            found_title = link.split('/')[-1].replace('.html', '').replace('-', ' ').title()

                        # Szukaj roku w pobliżu tego linku (w obrębie 1000 znaków)
                        found_year = None
                        link_pos = result.find(link)
                        if link_pos >= 0:
                            start_search = max(0, link_pos - 500)
                            end_search = min(len(result), link_pos + 500)
                            region = result[start_search:end_search]

                            # Szukaj span z label-year
                            year_match = re.search(r'<span[^>]*class="[^"]*label-year[^"]*"[^>]*>\s*(\d{4})\s*</span>', region)
                            if year_match:
                                try:
                                    found_year = int(year_match.group(1))
                                except:
                                    pass

                        # fflog(f"Znaleziony film: '{found_title}' ({found_year}) -> {full_url}")

                        if found_title:
                            search_results.append({
                                "url": full_url,
                                "title": found_title,
                                "year": found_year
                            })

                    # fflog(f"[{idx+1}/{len(titles_to_search)}] Znaleziono {len(search_results)} wyników")

                    # Sprawdź każdy wynik
                    for result_idx, item in enumerate(search_results):
                        try:
                            found_url = item["url"]
                            found_title = item["title"]
                            found_year = item.get("year")

                            # fflog(f"[{idx+1}/{len(titles_to_search)}][{result_idx+1}] Sprawdzam: '{found_title}' (rok: {found_year})")

                            # Sprawdź dopasowanie roku - na stronie wyszukiwania mamy rok, więc można łatwo porównać
                            year_match = True
                            if year and found_year:
                                if content_type == "movie":
                                    # Dla filmów tolerancja 1 rok
                                    year_match = abs(int(year) - found_year) <= 1
                                else:
                                    # Dla seriali większa tolerancja
                                    year_match = found_year >= int(year) - 1 and found_year <= int(year) + 5

                                # fflog(f"[{idx+1}/{len(titles_to_search)}][{result_idx+1}] Porównanie roku: szukany {year} vs znaleziony {found_year} = {year_match}")

                                if not year_match:
                                    # fflog(f"[{idx+1}/{len(titles_to_search)}][{result_idx+1}] Rok nie pasuje - pomijam")
                                    continue

                            # Sprawdź dopasowanie tytułu
                            search_clean = cleantitle.get_simple(search_title)
                            found_clean = cleantitle.get_simple(found_title)

                            if search_clean in found_clean or found_clean in search_clean:
                                # fflog(f'[{idx+1}/{len(titles_to_search)}] ZNALEZIONO DOPASOWANIE: {found_url} dla "{search_title}" -> "{found_title}" ({found_year})')
                                return found_url
                            else:
                                # fflog(f"[{idx+1}/{len(titles_to_search)}][{result_idx+1}] Tytuł nie pasuje: '{search_clean}' vs '{found_clean}'")
                                pass

                        except Exception:
                            # fflog(f'[{idx+1}/{len(titles_to_search)}][{result_idx+1}] Błąd przetwarzania wyniku')
                            fflog_exc(1)
                            continue

                    # fflog(f"[{idx+1}/{len(titles_to_search)}] Brak dopasowań dla '{search_title}'")

                except Exception:
                    # fflog(f'[{idx+1}/{len(titles_to_search)}] Błąd ogólny dla "{search_title}"')
                    fflog_exc(1)
                    continue

            fflog("Przeszukano wszystkie tytuły - nic nie znaleziono")
            return None

        except Exception:
            fflog_exc(1)
            return None

    def sources(self, url, hostDict, hostprDict):
        # fflog(f'{url=}   {hostDict=} {hostprDict=}')
        sources = []
        if not url:
            return sources
        try:
            # fflog(f"Pobieranie źródeł z: {url}")

            if '?key=' in url:
                # fflog("URL zawiera już klucz, traktuję jako pojedyncze źródło")
                provider = 'telewizjada'
                marked_link = f"{url}&provider={provider}"
                filename = ""
                filename = url.split("/")[-1].replace(".html", "") if "/" in url else ""
                filename = filename[:filename.find("?")]
                source_item = {
                    "source": provider.lower(),
                    "quality": "720p",  # Default quality for episode links
                    "language": "pl",
                    "url": marked_link,
                    "info": '',
                    "direct": False,
                    # "direct": True,
                    "debridonly": False,
                    # "filename": filename,
                    "info2": filename,
                    "valid": True,
                    "host": provider
                }
                sources.append(source_item)
                # fflog(f"sources={json.dumps(sources, indent=2)}")
                fflog(f'Przekazano źródeł: {len(sources)}')
                return sources

            result = requests.get(url, headers=self.headers, timeout=30).text
            if not result:
                return sources
            season_divs = client.parseDOM(result, "div", attrs={"class": "season"})
            for season_div in season_divs:
                links = client.parseDOM(season_div, "a", ret="href")
                texts = client.parseDOM(season_div, "a")
                for i, plink in enumerate(links):
                    if not plink or plink.startswith("#"):
                        continue
                    text = texts[i] if i < len(texts) else ""
                    if "youtube" in plink.lower() or "zwiastun" in text.lower():
                        continue

                    server_name_raw = text.strip()
                    server_name = server_name_raw.lower()

                    if 'telewizjada mpd' in server_name:
                        # fflog(f"Pomijam źródło 'Telewizjada MPD' (nieobsługiwane DRM): {plink}")
                        continue

                    if "?key=" not in plink:
                        continue

                    if not server_name:
                        server_name = "unknown"

                    provider_marker = f"&provider={server_name}"
                    marked_link = plink + provider_marker
                    quality = "HD"
                    if "1080" in text.lower():
                        quality = "1080p"
                    elif "720" in text.lower():
                        quality = "720p"
                    elif "480" in text.lower():
                        quality = "SD"
                    sources.append(self._create_source_item(marked_link, quality, "pl", server_name_raw, hostDict))
            unique_sources = []
            seen_urls = set()
            for source in sources:
                if source["url"] not in seen_urls:
                    unique_sources.append(source)
                    seen_urls.add(source["url"])
            # fflog(f"unique_sources={json.dumps(unique_sources, indent=2)}")
            fflog(f'Przekazano źródeł: {len(unique_sources)}')
            return unique_sources
        except Exception:
            fflog_exc()
            return sources

    def _create_source_item(self, url, quality, language, source, hostDict):
        # fflog('[_create_source_item]')
        # fflog(f'{url=} {quality=} {language=} {source=} {hostDict=}')
        if not url.startswith("http"):
            url = urljoin(self.base_link, url)
        valid, host = source_utils.is_host_valid(url, hostDict)
        if not valid:
            try:
                from urllib.parse import urlparse
                parsed = urlparse(url)
                host = parsed.netloc.replace("www.", "").rsplit(".", 1)[0]
            except:
                host = "unknown"
        filename = ""
        filename = url.split("/")[-1].replace(".html", "") if "/" in url else ""
        filename = filename[:filename.find("?")]
        return {
            "source": source,
            "quality": quality,
            "language": language,
            "url": url,
            "info": '',
            "info2": filename,
            "direct": False,
            # "direct": True,  # ?
            "debridonly": False,
            # "filename": filename,
        }

    def resolve(self, url):
        try:
            # fflog(f'{url=}')
            provider = "unknown"
            if "&provider=" in url:
                provider = url.split("&provider=")[-1]
                url = url.split("&provider=")[0]

            # fflog(f"Rozwiązywanie URL dla dostawcy '{provider}': {url}")

            page_content = requests.get(url, headers=self.headers, timeout=60)
            if not page_content:
                fflog(f'page_content=')
                return None
            page_content = page_content.text
            iframe_url = None
            embed_containers = client.parseDOM(page_content, "div", attrs={"class": "video-embed-container"})
            if embed_containers:
                iframes = client.parseDOM(embed_containers[0], "iframe", ret="src")
                if iframes:
                    iframe_url = iframes[0]
                    if not iframe_url.startswith("http"):
                        iframe_url = urljoin(self.base_link, iframe_url)
                    # fflog(f"Znaleziono URL w iframe: {iframe_url}")

            if not iframe_url:
                fflog("❌ Nie znaleziono iframe na stronie")
                return None

            # --- Logika specyficzna dla dostawcy ---

            if provider == 'telewizjada mpd':
                # fflog("Używam dedykowanego resolvera dla Telewizjada MPD")
                iframe_content = requests.get(iframe_url, headers=self.headers, timeout=60)
                if not iframe_content:
                    fflog("Brak zawartości iframe dla MPD")
                    return None
                iframe_content = iframe_content.text
                manifest_match = re.search(r"const manifestUri\s*=\s*'([^']+)'", iframe_content)
                if not manifest_match:
                    fflog("❌ MPD - Nie znaleziono manifestUri")
                    return None
                manifest_url = manifest_match.group(1)
                # fflog(f"✅ MPD - Znaleziono manifest: {manifest_url}")

                keys_match = re.search(r'clearKeys:\s*{\s*"([^"]+)":"([^"]+)"' , iframe_content)
                if not keys_match:
                    # fflog("MPD - Nie znaleziono clearKeys, próba odtworzenia bez kluczy")
                    adaptive_data = {
                        'protocol': 'mpd',
                        'mimetype': 'application/dash+xml',
                        'manifest': manifest_url,
                        'stream_headers': urlencode({'Referer': iframe_url, 'User-Agent': self.headers['User-Agent']})
                    }
                    fflog(f'wariant A')
                    # return manifest_url  # stream bez wymaganych zabezpieczeń (może być odtwarzany także przez standardowy odtwarzacz Kodi, choć wtedy mogą być problemy w przewijaniem)
                    return f"{manifest_url}|"+adaptive_data['stream_headers']
                    return f"DRMCDA|{repr(adaptive_data)}"  # wymusza użycie ISA

                key_id = keys_match.group(1)
                key = keys_match.group(2)
                # fflog(f"✅ MPD - Znaleziono klucze: KID={key_id}")
                adaptive_data = {
                    'protocol': 'mpd',
                    'mimetype': 'application/dash+xml',
                    'manifest': manifest_url,
                    'licence_type': 'org.w3.clearkey',
                    'licence_url': manifest_url,
                    'licence_header': '',
                    'post_data': '',
                    'response_data': '',
                    'stream_headers': urlencode({'Referer': iframe_url, 'User-Agent': self.headers['User-Agent']})
                }
                fflog(f'wariant B')
                # return f"manifest_url|#KODIPROP:inputstream.adaptive.drm_legacy=org.w3.clearkey|{key_id}:{key}"  # może i by zadziałało, trzeba by sprawdzić
                return f"DRMCDA|{repr(adaptive_data)}|#KODIPROP:inputstream.adaptive.drm_legacy=org.w3.clearkey|{key_id}:{key}"

            elif provider == 'telewizjada':
                # fflog("Używam dedykowanego resolvera dla Telewizjady")
                if 'serwer.telewizjada.cc' in iframe_url and iframe_url.endswith('.mp4/embed.html'):
                    final_url = iframe_url.replace('/embed.html', '/index.m3u8')
                    # fflog(f"✅ TELEWIZJADA - Skonstruowano link HLS: {final_url}")
                    fflog(f'wariant C')
                    final_url = "direct:" + final_url  # aby resolver nie rozwiązywał
                    return f"{final_url}|Referer={iframe_url}&User-Agent={quote(self.headers.get('User-Agent', ''))}"

                if 'tvdarmowa.cc' in iframe_url:
                    # fflog(f"✅ TELEWIZJADA - Zwracam URL tvdarmowa.cc: {iframe_url}")
                    fflog(f'wariant D')
                    """
                    iframe_content = requests.get(f"{iframe_url}|Sec-Fetch-Dest=iframe&Alt-Used=tvdarmowa.cc&Host=tvdarmowa.cc&Referer=https://film.telewizjada.cc&User-Agent={quote(self.headers.get('User-Agent', ''))}&Upgrade-Insecure-Requests=1&Connection=keep-alive&TE=trailers"
                                                   , headers=self.headers, timeout=60)
                    # fflog(f'{iframe_content=}',1,1)
                    iframe_content = iframe_content.text
                    # fflog(f'{iframe_content=}',1,1)
                    """
                    # iframe_url = "ia://" + iframe_url  # próba przez ISA
                    iframe_url = "direct:" + iframe_url  # aby resolver nie rozwiązywał
                    return f"{iframe_url}|Referer=https://film.telewizjada.cc"
                    # return f"{iframe_url}|Host=tvdarmowa.cc&Referer=https://film.telewizjada.cc&User-Agent={quote(self.headers.get('User-Agent', ''))}&Upgrade-Insecure-Requests=1&Connection=keep-alive&TE=trailers"

                fflog("❌ TELEWIZJADA - Nie udało się rozwiązać linku (nie tvdarmowa.cc ani serwer.telewizjada.cc)")
                return None

            else:  # Dla doodstream i innych
                # fflog(f"Używam domyślnego resolvera (iframe) dla '{provider}'")
                fflog(f'wariant E')
                return iframe_url

        except Exception:
            # fflog("❌ BŁĄD W RESOLVE:")
            fflog_exc(1)
            return None
